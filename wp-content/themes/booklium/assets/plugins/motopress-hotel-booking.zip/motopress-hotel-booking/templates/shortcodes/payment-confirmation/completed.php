<?php
/*
 * @since 3.7.0
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<p>
    <?php _e('Thank you for your payment. Your transaction has been completed.', 'motopress-hotel-booking'); ?>
</p>