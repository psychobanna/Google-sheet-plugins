<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php _e( 'Cancelation of your booking is not possible for some reason. Please contact the website administrator.', 'motopress-hotel-booking' ); ?>
</p>
