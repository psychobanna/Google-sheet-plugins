<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php _e( 'Booking is already canceled.', 'motopress-hotel-booking' ); ?>
</p>
