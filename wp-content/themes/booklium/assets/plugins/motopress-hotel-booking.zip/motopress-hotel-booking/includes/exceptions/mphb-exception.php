<?php

namespace MPHB\Exceptions;

class MPHBException extends \Exception {}
