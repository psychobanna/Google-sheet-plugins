<?php

global $wpdb;

$table_name = $wpdb->prefix . "googlesheetplugin_auth";
$data = $wpdb->get_results("SELECT * FROM " . $table_name);

$spreadsheetID = $data[0]->name;

if($spreadsheetID == null ){
	header("location:admin.php?page=authentication");
}

$table_name = $wpdb->prefix . "googlesheetplugin_product";
$data = $wpdb->get_results("SELECT * FROM " . $table_name);

if ($wpdb->num_rows) {
	if ($_POST) {

		// Then we use the product ID to set all the posts meta
		wp_set_object_terms($post_id, 'simple', 'product_type'); // set product is simple/variable/grouped
		update_post_meta($post_id, '_visibility', 'visible');
		update_post_meta($post_id, '_stock_status', 'instock');
		update_post_meta($post_id, 'total_sales', '0');
		update_post_meta($post_id, '_downloadable', 'no');
		update_post_meta($post_id, '_virtual', 'yes');
		update_post_meta($post_id, '_regular_price', '');
		update_post_meta($post_id, '_sale_price', '');
		update_post_meta($post_id, '_purchase_note', '');
		update_post_meta($post_id, '_featured', 'no');
		update_post_meta($post_id, '_weight', '');
		update_post_meta($post_id, '_length', '');
		update_post_meta($post_id, '_width', '');
		update_post_meta($post_id, '_height', '');
		update_post_meta($post_id, '_sku', 'google_sheet_data');
		update_post_meta($post_id, '_product_attributes', array());
		update_post_meta($post_id, '_sale_price_dates_from', '');
		update_post_meta($post_id, '_sale_price_dates_to', '');
		update_post_meta($post_id, '_sold_individually', '');
		update_post_meta($post_id, '_manage_stock', 'yes'); // activate stock management
		update_post_meta($post_id, '_backorders', 'no');

		// Price
		update_post_meta($post_id, '_price', '11');
		// Stock
		wc_update_product_stock($post_id, 100, 'set'); // set 1000 in stock
	}
} else {
	$post_id = create_Products_Programmatically();
	$wpdb->insert($table_name, array('name' => $post_id));
}


function create_Products_Programmatically()
{

	// Set number of products to create
	$number_of_products = 1;

	for ($i = 1; $i <= $number_of_products; $i++) {
		// First we create the product post so we can grab it's ID 
		$post_id = wp_insert_post(
			array(
				'post_title' => 'Product ' . $i,
				'post_type' => 'product',
				'post_status' => 'publish'
			)
		);

		// Then we use the product ID to set all the posts meta
		wp_set_object_terms($post_id, 'simple', 'product_type'); // set product is simple/variable/grouped
		update_post_meta($post_id, '_visibility', 'visible');
		update_post_meta($post_id, '_stock_status', 'instock');
		update_post_meta($post_id, 'total_sales', '0');
		update_post_meta($post_id, '_downloadable', 'no');
		update_post_meta($post_id, '_virtual', 'yes');
		update_post_meta($post_id, '_regular_price', '');
		update_post_meta($post_id, '_sale_price', '');
		update_post_meta($post_id, '_purchase_note', '');
		update_post_meta($post_id, '_featured', 'no');
		update_post_meta($post_id, '_weight', '11');
		update_post_meta($post_id, '_length', '11');
		update_post_meta($post_id, '_width', '11');
		update_post_meta($post_id, '_height', '11');
		update_post_meta($post_id, '_sku', 'SKU11');
		update_post_meta($post_id, '_product_attributes', array());
		update_post_meta($post_id, '_sale_price_dates_from', '');
		update_post_meta($post_id, '_sale_price_dates_to', '');
		update_post_meta($post_id, '_price', '11');
		update_post_meta($post_id, '_sold_individually', '');
		update_post_meta($post_id, '_manage_stock', 'yes'); // activate stock management
		wc_update_product_stock($post_id, 100, 'set'); // set 1000 in stock
		update_post_meta($post_id, '_backorders', 'no');
	}

	return $post_id;
}
